
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package niceeli.chickenbumblebee.init;

import niceeli.chickenbumblebee.item.BumblebeeItem;
import niceeli.chickenbumblebee.ChickenbumblebeeMod;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

public class ChickenbumblebeeModItems {
	public static Item BUMBLEBEE;

	public static void load() {
		BUMBLEBEE = Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(ChickenbumblebeeMod.MODID, "bumblebee"), new BumblebeeItem());
	}
}
