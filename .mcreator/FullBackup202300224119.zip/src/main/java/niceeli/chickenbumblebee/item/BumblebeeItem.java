
package niceeli.chickenbumblebee.item;

import niceeli.chickenbumblebee.init.ChickenbumblebeeModSounds;

import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

public class BumblebeeItem extends RecordItem {
	public BumblebeeItem() {
		super(0, ChickenbumblebeeModSounds.BEE, new Item.Properties().stacksTo(1).rarity(Rarity.RARE), 100);
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(content -> content.accept(this));
	}

	@Override
	@Environment(EnvType.CLIENT)
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}
